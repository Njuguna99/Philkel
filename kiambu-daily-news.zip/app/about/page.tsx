import Header from "@/components/header"
import Footer from "@/components/footer"
import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-red-700 mb-6">About Us</h1>

          <div className="mb-8">
            <Image
              src="/placeholder.svg?height=400&width=800"
              alt="Kiambu Daily News Team"
              width={800}
              height={400}
              className="w-full h-auto rounded-lg mb-4"
            />
            <p className="text-sm text-gray-600 italic text-center">
              The Kiambu Daily News editorial team at our headquarters in Kiambu Town
            </p>
          </div>

          <div className="prose max-w-none">
            <h2>Our Story</h2>
            <p>
              Kiambu Daily News was established in 2015 with a simple mission: to provide accurate, timely, and relevant
              news to the residents of Kiambu County and beyond. What started as a small online platform has grown into
              one of the most trusted news sources in the region, thanks to our commitment to journalistic integrity and
              community engagement.
            </p>

            <h2>Our Mission</h2>
            <p>
              At Kiambu Daily News, our mission is to inform, educate, and empower our readers through high-quality
              journalism that matters to their daily lives. We strive to be the primary source of news and information
              for Kiambu County, covering everything from local politics and business to lifestyle and entertainment.
            </p>

            <h2>Our Values</h2>
            <ul>
              <li>
                <strong>Accuracy:</strong> We are committed to factual reporting and thorough fact-checking to ensure
                that our readers receive reliable information.
              </li>
              <li>
                <strong>Independence:</strong> We maintain editorial independence and are not influenced by political or
                commercial interests.
              </li>
              <li>
                <strong>Community Focus:</strong> We prioritize stories that matter to the people of Kiambu County and
                contribute to community development.
              </li>
              <li>
                <strong>Inclusivity:</strong> We strive to represent diverse voices and perspectives in our coverage.
              </li>
              <li>
                <strong>Innovation:</strong> We embrace new technologies and storytelling formats to better serve our
                audience in the digital age.
              </li>
            </ul>

            <h2>Our Team</h2>
            <p>
              Our dedicated team consists of experienced journalists, editors, photographers, and digital media
              specialists who are passionate about delivering quality news content. Many of our team members are natives
              of Kiambu County, giving us a deep understanding of local issues and concerns.
            </p>

            <h2>Our Coverage</h2>
            <p>Kiambu Daily News covers a wide range of topics, including:</p>
            <ul>
              <li>Local and national politics</li>
              <li>Business and economic developments</li>
              <li>Education and healthcare</li>
              <li>Agriculture and land issues</li>
              <li>Culture and lifestyle</li>
              <li>Sports and entertainment</li>
              <li>Technology and innovation</li>
            </ul>

            <h2>Community Engagement</h2>
            <p>
              We believe in the power of journalism to drive positive change. That's why we regularly organize community
              forums, workshops, and events that bring together residents, leaders, and experts to discuss important
              issues affecting Kiambu County. We also provide platforms for citizen journalism, allowing community
              members to contribute their stories and perspectives.
            </p>

            <h2>Our Achievements</h2>
            <p>
              Since our inception, Kiambu Daily News has received several awards for excellence in journalism,
              including:
            </p>
            <ul>
              <li>Best County-Based Digital News Platform (2022)</li>
              <li>Excellence in Political Reporting (2021)</li>
              <li>Community Service Award (2020)</li>
              <li>Innovation in Digital Media (2019)</li>
            </ul>

            <h2>Connect With Us</h2>
            <p>
              We value your feedback and suggestions. Feel free to reach out to us through our contact page or social
              media channels. You can also subscribe to our newsletter to receive daily updates on the latest news from
              Kiambu County.
            </p>

            <p>
              Thank you for your continued support and readership. We remain committed to serving the people of Kiambu
              County with news that informs, inspires, and empowers.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

