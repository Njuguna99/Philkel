import Image from "next/image"
import Link from "next/link"
import Header from "@/components/header"
import Footer from "@/components/footer"
import TrendingNews from "@/components/trending-news"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Main content */}
      <main className="container mx-auto px-4 py-6 flex flex-col lg:flex-row gap-8">
        {/* Left column - Featured stories */}
        <div className="lg:w-3/4">
          <div className="mb-8">
            <div className="bg-red-700 text-white px-4 py-1 inline-block mb-4">
              <h2 className="font-bold">FEATURED STORIES</h2>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Main featured story */}
              <div className="md:col-span-2">
                <div className="relative">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    alt="Kiambu Constituency Residents"
                    width={600}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
                <h3 className="text-2xl font-bold mt-4 mb-2">
                  <Link href="/news/kiambu-constituency-residents" className="hover:text-red-700">
                    Kiambu Constituency Residents Demand Charges Against Surveyor Kigathi Kionywe Be Dropped
                  </Link>
                </h3>
                <div className="text-sm text-gray-600 mb-3">
                  <span className="font-semibold">Sponsor:</span>{" "}
                  <Link href="/sponsor/giamic" className="hover:underline">
                    Giamic Web Designs
                  </Link>{" "}
                  — April 4, 2025
                </div>
                <p className="text-gray-700">
                  Residents of Kiambu Constituency have expressed their disappointment over the ongoing arson and
                  destruction of property case against surveyor Kigathi Kionywe. They argue that the case is politically
                  motivated, citing a lack of concrete evidence to support the...
                </p>
                <Link
                  href="/news/kiambu-constituency-residents"
                  className="inline-block mt-3 text-red-700 font-medium hover:underline"
                >
                  Read More
                </Link>
              </div>

              {/* Side stories */}
              <div className="space-y-6">
                <div>
                  <Image
                    src="/placeholder.svg?height=200&width=300"
                    alt="Kiambu Constituency"
                    width={300}
                    height={200}
                    className="w-full h-auto"
                  />
                  <h3 className="text-lg font-bold mt-2 mb-1">
                    <Link href="/news/kiambu-constituency-residents-2" className="hover:text-red-700">
                      Kiambu Constituency Residents Demand Charges Against Surveyor Kigathi Kionywe Be Dropped
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600">
                    <span className="font-semibold">Sponsor:</span>{" "}
                    <Link href="/sponsor/giamic" className="hover:underline">
                      Giamic Web Designs
                    </Link>{" "}
                    — April 4, 2025
                  </div>
                </div>

                <div>
                  <Image
                    src="/placeholder.svg?height=200&width=300"
                    alt="Governor Kimani Wamatangi"
                    width={300}
                    height={200}
                    className="w-full h-auto"
                  />
                  <h3 className="text-lg font-bold mt-2 mb-1">
                    <Link href="/news/governor-kimani-wamatangi" className="hover:text-red-700">
                      Governor Kimani Wamatangi Pledges to Complete All ECD Schools in Kiambu by December
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600">
                    <span className="font-semibold">Sponsor:</span>{" "}
                    <Link href="/sponsor/giamic" className="hover:underline">
                      Giamic Web Designs
                    </Link>{" "}
                    — April 2, 2025
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-bold mb-1">
                    <Link href="/news/president-ruto-claims" className="hover:text-red-700">
                      President Ruto Claims Rigathi Gachagua Demanded Ksh 10 Billion Before His Impeachment
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600">
                    <span className="font-semibold">Sponsor:</span>{" "}
                    <Link href="/sponsor/primeyard" className="hover:underline">
                      Primeyard Properties Limited
                    </Link>{" "}
                    — March 31, 2025
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* More stories */}
          <div className="grid md:grid-cols-2 gap-6 mt-8">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <Image
                  src="/placeholder.svg?height=100&width=150"
                  alt="Mt. Kenya Region"
                  width={150}
                  height={100}
                  className="w-32 h-auto"
                />
              </div>
              <div>
                <h3 className="text-lg font-bold mb-1">
                  <Link href="/news/mt-kenya-region" className="hover:text-red-700">
                    Mt. Kenya Region: A Surge in Political Parties Ahead of 2027 Elections
                  </Link>
                </h3>
                <div className="text-xs text-gray-600">
                  <span className="font-semibold">Sponsor:</span>{" "}
                  <Link href="/sponsor/giamic" className="hover:underline">
                    Giamic Web Designs
                  </Link>{" "}
                  — March 31, 2025
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <Image
                  src="/placeholder.svg?height=100&width=150"
                  alt="Rigathi Gachagua"
                  width={150}
                  height={100}
                  className="w-32 h-auto"
                />
              </div>
              <div>
                <h3 className="text-lg font-bold mb-1">
                  <Link href="/news/rigathi-gachagua-blocked" className="hover:text-red-700">
                    Rigathi Gachagua Almost Blocked from Addressing Naivasha Residents
                  </Link>
                </h3>
                <div className="text-xs text-gray-600">
                  <span className="font-semibold">Sponsor:</span>{" "}
                  <Link href="/sponsor/giamic" className="hover:underline">
                    Giamic Web Designs
                  </Link>{" "}
                  — March 29, 2025
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <Image
                  src="/placeholder.svg?height=100&width=150"
                  alt="Former Kiambu Governor"
                  width={150}
                  height={100}
                  className="w-32 h-auto"
                />
              </div>
              <div>
                <h3 className="text-lg font-bold mb-1">
                  <Link href="/news/former-kiambu-governor" className="hover:text-red-700">
                    Former Kiambu Governor Ferdinand Waititu Faces New Corruption Charges
                  </Link>
                </h3>
                <div className="text-xs text-gray-600">
                  <span className="font-semibold">Sponsor:</span>{" "}
                  <Link href="/sponsor/giamic" className="hover:underline">
                    Giamic Web Designs
                  </Link>{" "}
                  — March 28, 2025
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <Image
                  src="/placeholder.svg?height=100&width=150"
                  alt="President Ruto"
                  width={150}
                  height={100}
                  className="w-32 h-auto"
                />
              </div>
              <div>
                <h3 className="text-lg font-bold mb-1">
                  <Link href="/news/president-ruto-tour" className="hover:text-red-700">
                    Will President Ruto's Six-Day Tour of Mt. Kenya Region Restore His Popularity?
                  </Link>
                </h3>
                <div className="text-xs text-gray-600">
                  <span className="font-semibold">Sponsor:</span>{" "}
                  <Link href="/sponsor/primeyard" className="hover:underline">
                    Primeyard Properties Limited
                  </Link>{" "}
                  — March 27, 2025
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right column - Trending news */}
        <div className="lg:w-1/4">
          <TrendingNews />
        </div>
      </main>

      <Footer />
    </div>
  )
}

