import Image from "next/image"
import Link from "next/link"
import Header from "@/components/header"
import Footer from "@/components/footer"
import TrendingNews from "@/components/trending-news"

export default function PoliticsPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Main content */}
      <main className="container mx-auto px-4 py-6 flex flex-col lg:flex-row gap-8">
        {/* Left column - Politics news */}
        <div className="lg:w-3/4">
          <div className="mb-8">
            <div className="border-b border-red-700 pb-2 mb-6">
              <h1 className="text-3xl font-bold text-red-700">Politics</h1>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {/* Featured politics story */}
              <div className="md:col-span-2">
                <div className="relative">
                  <Image
                    src="/placeholder.svg?height=400&width=800"
                    alt="President Ruto and Rigathi Gachagua"
                    width={800}
                    height={400}
                    className="w-full h-auto"
                  />
                </div>
                <h2 className="text-2xl font-bold mt-4 mb-2">
                  <Link href="/news/president-ruto-claims" className="hover:text-red-700">
                    President Ruto Claims Rigathi Gachagua Demanded Ksh 10 Billion Before His Impeachment
                  </Link>
                </h2>
                <div className="text-sm text-gray-600 mb-3">
                  <span className="font-semibold">Sponsor:</span>{" "}
                  <Link href="/sponsor/primeyard" className="hover:underline">
                    Primeyard Properties Limited
                  </Link>{" "}
                  — March 31, 2025
                </div>
                <p className="text-gray-700">
                  In a shocking revelation that has sent ripples through Kenya's political landscape, President William
                  Ruto has claimed that his former deputy, Rigathi Gachagua, demanded a staggering Ksh 10 billion before
                  his impeachment. According to sources close to the presidency, this demand was allegedly made during
                  private negotiations aimed at resolving the growing tensions between the two leaders...
                </p>
                <Link
                  href="/news/president-ruto-claims"
                  className="inline-block mt-3 text-red-700 font-medium hover:underline"
                >
                  Read More
                </Link>
              </div>
            </div>

            {/* More politics stories */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
              <div className="border rounded-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt="Mt. Kenya Region"
                  width={300}
                  height={200}
                  className="w-full h-auto"
                />
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-1">
                    <Link href="/news/mt-kenya-region" className="hover:text-red-700">
                      Mt. Kenya Region: A Surge in Political Parties Ahead of 2027 Elections
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600 mb-2">
                    <span className="font-semibold">Sponsor:</span>{" "}
                    <Link href="/sponsor/giamic" className="hover:underline">
                      Giamic Web Designs
                    </Link>{" "}
                    — March 31, 2025
                  </div>
                  <p className="text-sm text-gray-700">
                    Political realignments are taking shape in the Mt. Kenya region as leaders position themselves for
                    the 2027 general elections...
                  </p>
                </div>
              </div>

              <div className="border rounded-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt="Rigathi Gachagua"
                  width={300}
                  height={200}
                  className="w-full h-auto"
                />
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-1">
                    <Link href="/news/rigathi-gachagua-blocked" className="hover:text-red-700">
                      Rigathi Gachagua Almost Blocked from Addressing Naivasha Residents
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600 mb-2">
                    <span className="font-semibold">Sponsor:</span>{" "}
                    <Link href="/sponsor/giamic" className="hover:underline">
                      Giamic Web Designs
                    </Link>{" "}
                    — March 29, 2025
                  </div>
                  <p className="text-sm text-gray-700">
                    Former Deputy President Rigathi Gachagua faced hostility in Naivasha as residents attempted to block
                    him from addressing a public gathering...
                  </p>
                </div>
              </div>

              <div className="border rounded-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt="President Ruto"
                  width={300}
                  height={200}
                  className="w-full h-auto"
                />
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-1">
                    <Link href="/news/president-ruto-tour" className="hover:text-red-700">
                      Will President Ruto's Six-Day Tour of Mt. Kenya Region Restore His Popularity?
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600 mb-2">
                    <span className="font-semibold">Sponsor:</span>{" "}
                    <Link href="/sponsor/primeyard" className="hover:underline">
                      Primeyard Properties Limited
                    </Link>{" "}
                    — March 27, 2025
                  </div>
                  <p className="text-sm text-gray-700">
                    President William Ruto has embarked on a six-day tour of the Mt. Kenya region in what political
                    analysts see as an attempt to regain support...
                  </p>
                </div>
              </div>

              <div className="border rounded-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt="Raila Odinga"
                  width={300}
                  height={200}
                  className="w-full h-auto"
                />
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-1">
                    <Link href="/news/raila-odinga-statement" className="hover:text-red-700">
                      Raila Odinga Issues Statement on Government of National Unity
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600 mb-2">
                    <span className="font-semibold">Sponsor:</span>{" "}
                    <Link href="/sponsor/giamic" className="hover:underline">
                      Giamic Web Designs
                    </Link>{" "}
                    — March 25, 2025
                  </div>
                  <p className="text-sm text-gray-700">
                    Opposition leader Raila Odinga has issued a comprehensive statement regarding his position on the
                    Government of National Unity...
                  </p>
                </div>
              </div>

              <div className="border rounded-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt="Kiambu County Assembly"
                  width={300}
                  height={200}
                  className="w-full h-auto"
                />
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-1">
                    <Link href="/news/kiambu-county-assembly" className="hover:text-red-700">
                      Kiambu County Assembly Passes Controversial Land Bill
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600 mb-2">
                    <span className="font-semibold">Sponsor:</span>{" "}
                    <Link href="/sponsor/primeyard" className="hover:underline">
                      Primeyard Properties Limited
                    </Link>{" "}
                    — March 22, 2025
                  </div>
                  <p className="text-sm text-gray-700">
                    The Kiambu County Assembly has passed a controversial land bill that has drawn mixed reactions from
                    residents and stakeholders...
                  </p>
                </div>
              </div>

              <div className="border rounded-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt="Political Rally"
                  width={300}
                  height={200}
                  className="w-full h-auto"
                />
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-1">
                    <Link href="/news/political-parties-funding" className="hover:text-red-700">
                      New Political Parties Funding Regulations Take Effect
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600 mb-2">
                    <span className="font-semibold">Sponsor:</span>{" "}
                    <Link href="/sponsor/giamic" className="hover:underline">
                      Giamic Web Designs
                    </Link>{" "}
                    — March 20, 2025
                  </div>
                  <p className="text-sm text-gray-700">
                    The Office of the Registrar of Political Parties has announced new funding regulations that will
                    significantly impact political parties...
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right column - Trending news */}
        <div className="lg:w-1/4">
          <TrendingNews />
        </div>
      </main>

      <Footer />
    </div>
  )
}

