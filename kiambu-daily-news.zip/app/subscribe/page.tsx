import Header from "@/components/header"
import Footer from "@/components/footer"

export default function SubscribePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-red-700 mb-6">Subscribe to Kiambu Daily News</h1>

          <div className="bg-gray-50 p-6 rounded-lg border mb-8">
            <h2 className="text-xl font-bold mb-4">Stay Informed with Kiambu Daily News</h2>
            <p className="text-gray-700 mb-6">
              Subscribe to our newsletter and get the latest news, updates, and exclusive content delivered directly to
              your inbox. Choose from our various subscription plans to get the most out of Kiambu Daily News.
            </p>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="border rounded-lg overflow-hidden bg-white">
                <div className="bg-red-700 text-white p-4 text-center">
                  <h3 className="text-xl font-bold">Basic</h3>
                  <div className="text-2xl font-bold mt-2">FREE</div>
                </div>
                <div className="p-4">
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Daily Newsletter
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Limited Access to Articles
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Breaking News Alerts
                    </li>
                  </ul>
                  <button className="w-full mt-6 bg-red-700 text-white px-4 py-2 rounded-md font-medium hover:bg-red-800 transition-colors">
                    Subscribe Now
                  </button>
                </div>
              </div>

              <div className="border rounded-lg overflow-hidden bg-white relative">
                <div className="absolute top-0 right-0 bg-yellow-400 text-black px-3 py-1 text-sm font-bold">
                  POPULAR
                </div>
                <div className="bg-red-700 text-white p-4 text-center">
                  <h3 className="text-xl font-bold">Premium</h3>
                  <div className="text-2xl font-bold mt-2">
                    Ksh 499<span className="text-sm font-normal">/month</span>
                  </div>
                </div>
                <div className="p-4">
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      All Basic Features
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Unlimited Access to Articles
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Exclusive Content
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Ad-Free Experience
                    </li>
                  </ul>
                  <button className="w-full mt-6 bg-red-700 text-white px-4 py-2 rounded-md font-medium hover:bg-red-800 transition-colors">
                    Subscribe Now
                  </button>
                </div>
              </div>

              <div className="border rounded-lg overflow-hidden bg-white">
                <div className="bg-red-700 text-white p-4 text-center">
                  <h3 className="text-xl font-bold">Business</h3>
                  <div className="text-2xl font-bold mt-2">
                    Ksh 999<span className="text-sm font-normal">/month</span>
                  </div>
                </div>
                <div className="p-4">
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      All Premium Features
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Business Intelligence Reports
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Market Analysis
                    </li>
                    <li className="flex items-center">
                      <svg
                        className="w-5 h-5 text-green-500 mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      Priority Customer Support
                    </li>
                  </ul>
                  <button className="w-full mt-6 bg-red-700 text-white px-4 py-2 rounded-md font-medium hover:bg-red-800 transition-colors">
                    Subscribe Now
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 p-6 rounded-lg border">
            <h2 className="text-xl font-bold mb-4">Newsletter Subscription</h2>
            <p className="text-gray-700 mb-6">
              If you prefer to receive only our newsletter, fill out the form below to subscribe for free.
            </p>

            <form className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                    First Name
                  </label>
                  <input
                    type="text"
                    id="firstName"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-red-700"
                    placeholder="Your first name"
                  />
                </div>
                <div>
                  <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                    Last Name
                  </label>
                  <input
                    type="text"
                    id="lastName"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-red-700"
                    placeholder="Your last name"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-red-700"
                  placeholder="Your email address"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Interests (Optional)</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Politics
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Business
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Lifestyle
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Technology
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Sports
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" className="mr-2" />
                    Entertainment
                  </label>
                </div>
              </div>

              <div>
                <label className="flex items-center">
                  <input type="checkbox" className="mr-2" />
                  <span className="text-sm text-gray-700">
                    I agree to receive newsletters and promotional emails from Kiambu Daily News
                  </span>
                </label>
              </div>

              <button
                type="submit"
                className="bg-red-700 text-white px-6 py-2 rounded-md font-medium hover:bg-red-800 transition-colors"
              >
                Subscribe to Newsletter
              </button>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

