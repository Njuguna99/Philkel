import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import Header from "@/components/header"
import Footer from "@/components/footer"
import TrendingNews from "@/components/trending-news"

interface NewsPageProps {
  params: {
    id: string
  }
}

export default function NewsPage({ params }: NewsPageProps) {
  // This would normally come from a database or API
  const newsArticles = {
    "kiambu-constituency-residents": {
      title: "Kiambu Constituency Residents Demand Charges Against Surveyor Kigathi Kionywe Be Dropped",
      image: "/placeholder.svg?height=600&width=1200",
      sponsor: "Giamic Web Designs",
      sponsorType: "designs",
      date: "April 4, 2025",
      content: `
        <p>Residents of Kiambu Constituency have expressed their disappointment over the ongoing arson and destruction of property case against surveyor Kigathi Kionywe. They argue that the case is politically motivated, citing a lack of concrete evidence to support the allegations.</p>
        
        <p>During a community meeting held at Kiambu Town on Tuesday, residents voiced their concerns about what they perceive as targeted persecution of Mr. Kionywe, who has been a vocal advocate for land rights in the region.</p>
        
        <p>"We have known Mr. Kionywe for many years as a professional who has helped many residents secure their land titles. These charges are clearly meant to silence him," said James Kamau, a community leader from Kiambu Town.</p>
        
        <p>The case stems from incidents reported in January 2025, where properties belonging to a local businessman were allegedly set ablaze. Prosecutors claim that Mr. Kionywe orchestrated the attacks following a land dispute with the businessman.</p>
        
        <p>However, residents argue that the timeline of events doesn't add up, as Mr. Kionywe was attending a professional conference in Mombasa when the incidents occurred.</p>
        
        <p>"There are witnesses who can confirm his whereabouts during the time of the alleged crime. We demand a fair investigation that considers all evidence," said Mary Wanjiku, another resident.</p>
        
        <p>The residents have formed a support committee and are planning to petition the Director of Public Prosecutions to review the case. They have also sought the intervention of local political leaders to ensure that justice is served.</p>
        
        <p>Mr. Kionywe, who was released on bail last month, has maintained his innocence and thanked the community for their support.</p>
        
        <p>"I am grateful for the solidarity shown by the people of Kiambu. I have served this community with integrity for over 15 years and will continue to do so. I trust that the truth will prevail," he said in a statement read by his lawyer.</p>
        
        <p>The case has attracted attention beyond Kiambu, with professional bodies such as the Institution of Surveyors of Kenya (ISK) calling for due process and a fair trial.</p>
        
        <p>As the case continues, residents have vowed to stand with Mr. Kionywe and ensure that his rights are protected. They plan to hold peaceful demonstrations next week to further press their demands.</p>
      `,
    },
    "president-ruto-claims": {
      title: "President Ruto Claims Rigathi Gachagua Demanded Ksh 10 Billion Before His Impeachment",
      image: "/placeholder.svg?height=600&width=1200",
      sponsor: "Primeyard Properties Limited",
      sponsorType: "properties",
      date: "March 31, 2025",
      content: `
        <p>In a shocking revelation that has sent ripples through Kenya's political landscape, President William Ruto has claimed that his former deputy, Rigathi Gachagua, demanded a staggering Ksh 10 billion before his impeachment. According to sources close to the presidency, this demand was allegedly made during private negotiations aimed at resolving the growing tensions between the two leaders.</p>
        
        <p>Speaking at a public rally in Nakuru on Sunday, President Ruto stated, "When we were discussing the way forward for our government, there were unreasonable demands placed on the table. I cannot compromise the interests of Kenyans for personal gain."</p>
        
        <p>While the President did not explicitly mention the Ksh 10 billion figure during his speech, insiders familiar with the matter confirmed to Kiambu Daily News that this was indeed the amount in question. The funds were allegedly meant to secure Gachagua's resignation before the impeachment process began.</p>
        
        <p>"The former Deputy President wanted a golden parachute that would have cost taxpayers billions. This was unacceptable," said a senior government official who requested anonymity due to the sensitivity of the matter.</p>
        
        <p>Gachagua, who was impeached by Parliament earlier this month on grounds of gross violation of the Constitution, abuse of office, and gross misconduct, has vehemently denied these allegations. Through his spokesperson, he described the claims as "malicious fabrications designed to tarnish his reputation."</p>
        
        <p>"The former Deputy President never made such demands. These are desperate attempts to justify an illegal and unconstitutional impeachment process," the spokesperson stated in a press release issued on Monday morning.</p>
        
        <p>Political analysts view this development as a strategic move by President Ruto to gain public support following the controversial impeachment that has divided the nation. Dr. Jane Muthoni, a political scientist at the University of Nairobi, noted that "by portraying Gachagua as greedy and self-serving, the President is attempting to legitimize the impeachment in the court of public opinion."</p>
        
        <p>The allegations have sparked mixed reactions among Kenyans. While some believe the President's claims, others have expressed skepticism, viewing them as political propaganda aimed at discrediting Gachagua, who has remained popular, especially in the Mt. Kenya region.</p>
        
        <p>Members of Parliament allied to the former Deputy President have called for evidence to support these serious allegations. "If indeed such a demand was made, there must be records of these discussions. We challenge the President to provide proof rather than making unsubstantiated claims," said Hon. James Kamau, MP for Kiambu Town.</p>
        
        <p>As the political drama unfolds, legal experts have weighed in on the matter, noting that if proven true, such demands could constitute an attempt at extortion, which is a criminal offense under Kenyan law.</p>
        
        <p>"If there is credible evidence that such demands were made, this could lead to criminal charges against the former Deputy President," said Advocate Sarah Wanjiru, a constitutional law expert.</p>
        
        <p>The controversy comes at a time when President Ruto is facing challenges in consolidating his support in the Mt. Kenya region, which was a key voting bloc in the 2022 elections. Political observers believe that the fallout with Gachagua could significantly impact the President's political fortunes in the region ahead of the 2027 elections.</p>
        
        <p>As this story develops, Kenyans are keenly watching to see if more details will emerge regarding the alleged demand and how it will shape the country's political landscape in the coming months.</p>
      `,
    },
  }

  const article = newsArticles[params.id as keyof typeof newsArticles]

  if (!article) {
    notFound()
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Main content */}
      <main className="container mx-auto px-4 py-6 flex flex-col lg:flex-row gap-8">
        {/* Left column - Article content */}
        <div className="lg:w-3/4">
          <article className="mb-8">
            <h1 className="text-3xl font-bold mb-4">{article.title}</h1>

            <div className="text-sm text-gray-600 mb-6">
              <span className="font-semibold">Sponsor:</span>{" "}
              <Link
                href={article.sponsorType === "properties" ? "/sponsor/primeyard" : "/sponsor/giamic"}
                className="hover:underline"
              >
                {article.sponsor}
              </Link>{" "}
              — {article.date}
            </div>

            <div className="relative mb-6">
              <Image
                src={article.image || "/placeholder.svg"}
                alt={article.title}
                width={1200}
                height={600}
                className="w-full h-auto rounded-lg"
              />
            </div>

            <div
              className="prose max-w-none prose-headings:text-red-700 prose-a:text-red-700"
              dangerouslySetInnerHTML={{ __html: article.content }}
            />

            <div className="mt-8 pt-6 border-t">
              <h3 className="text-xl font-bold mb-4">Share this article</h3>
              <div className="flex gap-4">
                <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Facebook</button>
                <button className="bg-sky-500 text-white px-4 py-2 rounded-md hover:bg-sky-600">Twitter</button>
                <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">WhatsApp</button>
              </div>
            </div>
          </article>

          {/* Related articles */}
          <div className="mt-8 pt-6 border-t">
            <h2 className="text-2xl font-bold mb-6">Related Articles</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="border rounded-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt="Related Article"
                  width={300}
                  height={200}
                  className="w-full h-auto"
                />
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-1">
                    <Link href="/news/related-article-1" className="hover:text-red-700">
                      Kiambu County Assembly Debates Land Reform Bill
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600">
                    <span className="font-semibold">Sponsor:</span> Giamic Web Designs — April 3, 2025
                  </div>
                </div>
              </div>

              <div className="border rounded-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt="Related Article"
                  width={300}
                  height={200}
                  className="w-full h-auto"
                />
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-1">
                    <Link href="/news/related-article-2" className="hover:text-red-700">
                      Land Disputes on the Rise in Kiambu County
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600">
                    <span className="font-semibold">Sponsor:</span> Primeyard Properties Limited — March 30, 2025
                  </div>
                </div>
              </div>

              <div className="border rounded-md overflow-hidden">
                <Image
                  src="/placeholder.svg?height=200&width=300"
                  alt="Related Article"
                  width={300}
                  height={200}
                  className="w-full h-auto"
                />
                <div className="p-4">
                  <h3 className="text-lg font-bold mb-1">
                    <Link href="/news/related-article-3" className="hover:text-red-700">
                      Governor Wamatangi Addresses Land Grabbing Concerns
                    </Link>
                  </h3>
                  <div className="text-xs text-gray-600">
                    <span className="font-semibold">Sponsor:</span> Giamic Web Designs — March 28, 2025
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right column - Trending news */}
        <div className="lg:w-1/4">
          <TrendingNews />

          {/* Advertisement */}
          <div className="mt-8 p-4 border rounded-md bg-gray-50">
            <h3 className="text-lg font-bold mb-4 text-center">Advertisement</h3>
            <div className="flex justify-center">
              <Image
                src="/placeholder.svg?height=300&width=300"
                alt="Advertisement"
                width={300}
                height={300}
                className="w-full h-auto"
              />
            </div>
            <div className="mt-4 text-center">
              <h4 className="font-bold">Primeyard Properties Limited</h4>
              <p className="text-sm text-gray-700 mt-2">
                Discover your dream home in Kiambu County. Premium properties at affordable prices.
              </p>
              <button className="mt-4 bg-red-700 text-white px-4 py-2 rounded-md hover:bg-red-800">Learn More</button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

