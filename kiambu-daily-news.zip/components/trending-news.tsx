import Image from "next/image"
import Link from "next/link"

interface TrendingNewsItem {
  id: string
  title: string
  image: string
  sponsor: string
  sponsorType: "properties" | "designs"
  date: string
}

export default function TrendingNews() {
  const trendingNews: TrendingNewsItem[] = [
    {
      id: "1",
      title: "President Ruto Claims Rigathi Gachagua Demanded Ksh 10 Billion Before His Impeachment",
      image: "/placeholder.svg?height=80&width=80",
      sponsor: "Primeyard Properties Limited",
      sponsorType: "properties",
      date: "March 31, 2025",
    },
    {
      id: "2",
      title: "Why did Wakairu Wa Ndeiya quit Inooro FM after just two days of being on air?",
      image: "/placeholder.svg?height=80&width=80",
      sponsor: "Primeyard Properties Limited",
      sponsorType: "properties",
      date: "March 19, 2025",
    },
    {
      id: "3",
      title: "Why the ACK Archbishop Ole Sapit Banned Politics in the Church",
      image: "/placeholder.svg?height=80&width=80",
      sponsor: "Giamic Web Designs",
      sponsorType: "designs",
      date: "March 17, 2025",
    },
    {
      id: "4",
      title: "Emotional Plea: Nyanduma MCA Beth Wanjiku Breaks Down in the Presence of Deputy President",
      image: "/placeholder.svg?height=80&width=80",
      sponsor: "Primeyard Properties Limited",
      sponsorType: "properties",
      date: "March 13, 2025",
    },
    {
      id: "5",
      title: "Karangu Muraya and Trizah Mwanake Muraya: The Flour War Begins!",
      image: "/placeholder.svg?height=80&width=80",
      sponsor: "Giamic Web Designs",
      sponsorType: "designs",
      date: "March 11, 2025",
    },
    {
      id: "6",
      title: "What's Next for Muthee Kiengei? The Road Ahead for a Comedy Legend",
      image: "/placeholder.svg?height=80&width=80",
      sponsor: "Giamic Web Designs",
      sponsorType: "designs",
      date: "March 9, 2025",
    },
    {
      id: "7",
      title: "How Former DP Rigathi Gachagua Avoided the Ruto-Raila Agreement Discussions",
      image: "/placeholder.svg?height=80&width=80",
      sponsor: "Primeyard Properties Limited",
      sponsorType: "properties",
      date: "March 9, 2025",
    },
  ]

  return (
    <div>
      <div className="border-b pb-2 mb-4 flex justify-between items-center">
        <h2 className="text-xl font-bold text-red-700">Trending News</h2>
        <Link href="/more-news" className="text-sm text-gray-500 hover:text-gray-700">
          Read More
        </Link>
      </div>

      <div className="space-y-6">
        {trendingNews.map((news) => (
          <div key={news.id} className="flex gap-3">
            <div className="flex-shrink-0">
              <Image
                src={news.image || "/placeholder.svg"}
                alt={news.title}
                width={80}
                height={80}
                className="w-20 h-20 object-cover"
              />
            </div>
            <div>
              <h3 className="font-bold mb-1 text-sm">
                <Link href={`/news/${news.id}`} className="hover:text-red-700">
                  {news.title}
                </Link>
              </h3>
              <div className="text-xs text-gray-600">
                <span className="font-semibold">Sponsor:</span>{" "}
                <Link
                  href={news.sponsorType === "properties" ? "/sponsor/primeyard" : "/sponsor/giamic"}
                  className="hover:underline"
                >
                  {news.sponsor}
                </Link>{" "}
                — {news.date}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

