import Link from "next/link"
import { Facebook, Twitter, Instagram, Search } from "lucide-react"

export default function Header() {
  const currentDate = new Date()
  const options: Intl.DateTimeFormatOptions = { weekday: "long", month: "long", day: "numeric" }
  const formattedDate = currentDate.toLocaleDateString("en-US", options)

  return (
    <>
      {/* Top bar */}
      <div className="bg-black text-white py-1 px-4 flex justify-between items-center text-sm">
        <div>{formattedDate}</div>
        <div className="flex items-center gap-4">
          <Link href="/about" className="hover:text-gray-300">
            About Us
          </Link>
          <Link href="/advertise" className="hover:text-gray-300">
            Advertise with Us
          </Link>
          <Link href="/ethics" className="hover:text-gray-300">
            Our Work Ethics
          </Link>
          <div className="flex items-center gap-2 ml-4">
            <Link href="#" aria-label="Facebook">
              <Facebook size={16} />
            </Link>
            <Link href="#" aria-label="Twitter">
              <Twitter size={16} />
            </Link>
            <Link href="#" aria-label="Instagram">
              <Instagram size={16} />
            </Link>
            <Link href="#" aria-label="Search">
              <Search size={16} />
            </Link>
          </div>
        </div>
      </div>

      {/* Header with logo and navigation */}
      <header className="bg-red-700 text-white">
        <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
          <div className="text-center mb-4 md:mb-0">
            <Link href="/" className="inline-block">
              <h1 className="text-4xl font-bold">Kiambu Daily News</h1>
              <p className="text-sm">The county headlines going beyond news</p>
            </Link>
          </div>

          <nav className="flex flex-wrap justify-center gap-4 md:gap-6">
            <Link href="/" className="font-medium hover:text-gray-200">
              Home
            </Link>
            <Link href="/politics" className="font-medium hover:text-gray-200">
              Politics
            </Link>
            <Link href="/business" className="font-medium hover:text-gray-200">
              Business
            </Link>
            <Link href="/lifestyle" className="font-medium hover:text-gray-200">
              Lifestyle
            </Link>
            <Link href="/technology" className="font-medium hover:text-gray-200">
              Technology
            </Link>
            <Link href="/sports" className="font-medium hover:text-gray-200">
              Sports
            </Link>
            <Link href="/entertainment" className="font-medium hover:text-gray-200">
              Entertainment
            </Link>
            <Link
              href="/subscribe"
              className="bg-yellow-400 text-black px-4 py-1 rounded-md font-medium hover:bg-yellow-500"
            >
              SUBSCRIBE
            </Link>
          </nav>
        </div>
      </header>
    </>
  )
}

