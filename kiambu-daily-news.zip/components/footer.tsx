import Link from "next/link"
import { Facebook, Twitter, Instagram } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8 mt-auto">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Kiambu Daily News</h3>
            <p className="text-gray-300">The county headlines going beyond news</p>
            <p className="text-gray-300 mt-4">
              Bringing you the latest news and updates from Kiambu County and beyond. Stay informed with our
              comprehensive coverage of local and national events.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-gray-300 hover:text-white">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-300 hover:text-white">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/advertise" className="text-gray-300 hover:text-white">
                  Advertise with Us
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-gray-300 hover:text-white">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-gray-300 hover:text-white">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/ethics" className="text-gray-300 hover:text-white">
                  Our Work Ethics
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Connect With Us</h3>
            <div className="flex gap-4 mb-6">
              <Link href="#" aria-label="Facebook" className="hover:text-gray-300">
                <Facebook />
              </Link>
              <Link href="#" aria-label="Twitter" className="hover:text-gray-300">
                <Twitter />
              </Link>
              <Link href="#" aria-label="Instagram" className="hover:text-gray-300">
                <Instagram />
              </Link>
            </div>
            <h3 className="text-lg font-bold mb-2">Subscribe to Newsletter</h3>
            <div className="flex">
              <input
                type="email"
                placeholder="Your email address"
                className="px-3 py-2 bg-gray-700 text-white rounded-l-md focus:outline-none focus:ring-1 focus:ring-yellow-400 w-full"
              />
              <button className="bg-yellow-400 text-black px-4 py-2 rounded-r-md font-medium hover:bg-yellow-500">
                Subscribe
              </button>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-4 text-center text-gray-400">
          <p>© {new Date().getFullYear()} Kiambu Daily News. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  )
}

